<?php
/**
 * Beranda (§7). Data dari HomeService::get() (cache 10 menit) + pilar dari SiteService.
 *
 * @var App\Core\View $this
 * @var list<array> $banner     id, judul, foto, foto_mobile, link, dim, dim_mobile
 * @var list<array> $layanan
 * @var list<array> $pilar
 * @var array<string, list<array>> $kabar  per tab HomeService::TAB_KABAR
 * @var list<array> $video
 * @var list<array> $zakat      judul, slug
 * @var list<array> $testimoni
 * @var list<array> $mitra      id, nama, logo, dim
 */

use App\Services\HomeService;

$namaSitus = setting('site_name', (string) config('app.name'));
$blok      = 'mx-auto max-w-6xl px-4 py-10 lg:py-16';

// --- Hero: rasio mengikuti banner yang ada (±16:7). Rasio 4:3 di HP hanya bila SEMUA banner punya foto_mobile.
$semuaPunyaMobile = $banner !== [] && count(array_filter($banner, static fn (array $b): bool => !empty($b['foto_mobile']))) === count($banner);
// Laptop (≥ lg): selebar layar, tinggi maks. 75% layar (monitor sangat lebar: dipotong atas-bawah, bukan memanjang)
$rasioHero  = ($semuaPunyaMobile ? 'aspect-[4/3] sm:aspect-[16/7]' : 'aspect-[16/7]') . ' lg:max-h-[75vh] lg:w-full';
$sizesHero  = '(min-width: 1024px) 100vw, calc(100vw - 2rem)';
$pertama    = $banner[0] ?? null;

// Preload gambar LCP (slide pertama) agar mulai diunduh sebelum CSS selesai
if ($pertama !== null) {
    $this->start('head');
    $srcsetDesktop = img_srcset($pertama['foto'], 'banner', $pertama['dim'][0] ?? 1600);
    if ($semuaPunyaMobile) {
        $srcsetMobile = img_srcset($pertama['foto_mobile'], 'banner', $pertama['dim_mobile'][0] ?? 1200);
        echo '<link rel="preload" as="image" fetchpriority="high" media="(max-width: 639px)" imagesrcset="' . e((string) $srcsetMobile) . '" imagesizes="' . e($sizesHero) . '">' . "\n";
        echo '<link rel="preload" as="image" fetchpriority="high" media="(min-width: 640px)" imagesrcset="' . e((string) $srcsetDesktop) . '" imagesizes="' . e($sizesHero) . '">' . "\n";
    } elseif ($srcsetDesktop !== null) {
        echo '<link rel="preload" as="image" fetchpriority="high" imagesrcset="' . e($srcsetDesktop) . '" imagesizes="' . e($sizesHero) . '">' . "\n";
    }
    $this->stop();
}

$slideHero = [];
foreach ($banner as $i => $b) {
    [$w, $h] = $b['dim'] ?? [1600, 700];
    $gambar = img($b['foto'], 'banner', $b['judul'], [
        'width' => $w, 'height' => $h, 'sizes' => $sizesHero, 'eager' => $i === 0, 'rendah' => $i > 0,
        'class' => 'size-full object-cover',
    ]);
    if ($semuaPunyaMobile) {
        [$mw, $mh] = $b['dim_mobile'] ?? [1200, 900];
        $gambar = '<picture><source media="(max-width: 639px)" srcset="' . e((string) img_srcset($b['foto_mobile'], 'banner', $mw))
            . '" sizes="' . e($sizesHero) . '" width="' . $mw . '" height="' . $mh . '">' . $gambar . '</picture>';
    }
    $isi = '<div class="' . $rasioHero . ' overflow-hidden rounded-2xl bg-surface lg:rounded-none">' . $gambar . '</div>';
    $slideHero[] = !empty($b['link'])
        ? '<a href="' . e(url($b['link'])) . '" class="block rounded-2xl lg:rounded-none">' . $isi . '</a>'
        : $isi;
}

// --- Organisasi (JSON-LD)
$organisasi = array_filter([
    '@context'  => 'https://schema.org',
    '@type'     => 'NGO',
    'name'      => $namaSitus,
    'alternateName' => 'BAZNAS Basel',
    'url'       => url(),
    'logo'      => url('assets/img/icon-512.png'),
    'email'     => setting('email'),
    'telephone' => setting('telepon'),
    'address'   => setting('alamat') ? ['@type' => 'PostalAddress', 'streetAddress' => setting('alamat'), 'addressLocality' => 'Toboali', 'addressRegion' => 'Kepulauan Bangka Belitung', 'addressCountry' => 'ID'] : null,
    'sameAs'    => array_values(array_filter([setting('instagram'), setting('facebook'), setting('youtube'), setting('tiktok'), setting('twitter')])),
]);

$this->layout('site', [
    'description' => 'Tunaikan zakat, infaq, dan sedekah melalui BAZNAS Kabupaten Bangka Selatan: bayar zakat online, kalkulator zakat, program, dan kabar terbaru.',
    'image'       => $pertama ? url('uploads/banner/' . rawurlencode($pertama['foto'])) : null,
    'jsonLd'      => [$organisasi],
]);

// Ikon berwarna: Bayar Zakat = SVG inline (partials/ikon-nav); lainnya WebP transparan dari public/icon/*.png
// (assets/img/aksi/{nama}-72|108.webp, ±3 KB; aslinya ±1 MB).
// Ikon menu bilah navigasi bawah (per URL tujuan) untuk hiasan di atas judul bagian
$ikonBawah = [];
foreach (App\Services\Navigation::bawah() as $n) {
    if ($n['url'] !== null && $n['svg'] !== null) {
        $ikonBawah[$n['url']] = $n;
    }
}
$navLayanan = $ikonBawah['/layanan'] ?? null;
$navProgram = $ikonBawah['/program'] ?? null;
?>
<h1 class="sr-only"><?= e($namaSitus) ?> — <?= e(setting('tagline', 'Badan Amil Zakat Nasional')) ?></h1>

<?php /* 1. Hero banner */ ?>
<?php if ($slideHero !== []): ?>
<div class="mx-auto max-w-6xl px-4 pt-4 lg:max-w-none lg:px-0 lg:pt-0">
    <?= $this->insert('components/carousel', [
        'label'        => 'Banner utama',
        'slides'       => $slideHero,
        'itemClass'    => 'w-full',
        'autoplay'     => 6000,
        'panahSamping' => true,  // panah di kiri & kanan gambar
        'tombolJeda'   => false, // autoplay tetap berhenti saat hover/fokus/sentuh & prefers-reduced-motion
        'titik'        => false, // tanpa titik penanda → tanpa baris kontrol di bawah banner
    ]) ?>
</div>
<?php endif ?>

<?php /* 3. Tunaikan Zakat (layanan) */ ?>
<?php if ($layanan !== []): ?>
<section class="<?= $blok ?>" aria-labelledby="judul-layanan">
    <?php if ($navLayanan !== null): ?>
    <?php /* Ikon menu "Layanan" di bilah navigasi bawah (SVG bawaan atau gambar admin → Ikon Navigasi), dekoratif */ ?>
    <div class="mb-4 flex justify-center" aria-hidden="true">
        <?= $this->insert('partials/ikon-nav', ['nama' => $navLayanan['svg'], 'aktif' => false, 'berwarna' => true, 'ukuran' => 'size-20 lg:size-24', 'gambar' => $navLayanan['gambar']]) ?>
    </div>
    <?php endif ?>
    <?= $this->insert('components/section-title', [
        'judul' => 'Tunaikan Zakat', 'id' => 'judul-layanan', 'tengah' => true,
        'subjudul' => 'Pilih cara yang paling mudah untuk Anda.',
    ]) ?>
    <?php /* Maks. 4 kartu (Layanan::MAKS_BERANDA): 2 kolom di HP, 4 kolom di laptop */ ?>
    <ul class="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
        <?php foreach ($layanan as $l): ?>
        <li><?= $this->insert('components/card-layanan', ['layanan' => $l]) ?></li>
        <?php endforeach ?>
    </ul>
</section>
<?php endif ?>

<?php /* 4. Program Kami — 5 pilar: deret ikon + nama (ikon & warna dari admin → 5 Pilar) */ ?>
<section class="cv-auto bg-surface" aria-labelledby="judul-program">
    <div class="<?= $blok ?>">
        <?php if ($navProgram !== null): ?>
        <?php /* Ikon menu "Program" di bilah navigasi bawah, dekoratif */ ?>
        <div class="mb-4 flex justify-center" aria-hidden="true">
            <?= $this->insert('partials/ikon-nav', ['nama' => $navProgram['svg'], 'aktif' => false, 'berwarna' => true, 'ukuran' => 'size-20 lg:size-24', 'gambar' => $navProgram['gambar']]) ?>
        </div>
        <?php endif ?>
        <?= $this->insert('components/section-title', [
            'judul' => 'Program Kami', 'id' => 'judul-program', 'tengah' => true,
            'subjudul' => 'Lima pilar penyaluran zakat untuk masyarakat Bangka Selatan.',
        ]) ?>
        <ul class="mx-auto grid max-w-4xl grid-cols-5 gap-1.5 sm:gap-6">
            <?php foreach ($pilar as $p): ?>
            <li>
                <a href="<?= e(url('program/' . $p['slug'])) ?>" class="group flex flex-col items-center gap-2 rounded-2xl p-1 text-center sm:gap-3">
                    <span class="transition-transform duration-200 group-hover:-translate-y-1 motion-reduce:transition-none motion-reduce:group-hover:translate-y-0">
                        <?= $this->insert('components/ikon-pilar', ['pilar' => $p, 'kotak' => 'size-14 sm:size-24 lg:size-28', 'ukuranIkon' => 'size-7 sm:size-12 lg:size-14', 'ukuranUnggahan' => 'size-10 sm:size-16 lg:size-20', 'sizes' => '(min-width: 1024px) 80px, (min-width: 640px) 64px, 40px']) ?>
                    </span>
                    <span class="text-xs font-semibold leading-tight text-ink group-hover:text-primary sm:text-base"><?= e($p['label']) ?></span>
                </a>
            </li>
            <?php endforeach ?>
        </ul>
    </div>
</section>

<?php /* 6. Kabar BAZNAS */ ?>
<section class="cv-auto <?= $blok ?>" aria-labelledby="judul-kabar" data-tabs>
    <?= $this->insert('components/section-title', ['judul' => 'Kabar BAZNAS', 'id' => 'judul-kabar', 'link' => '/berita']) ?>
    <?= $this->insert('components/chip-tabs', [
        'label' => 'Jenis kabar',
        'items' => array_map(static fn (string $kunci, array $tab): array => [
            'label' => $tab[0],
            'url'   => $tab[1] === null ? '/berita' : '/berita?jenis=' . $tab[1],
            'aktif' => $kunci === 'semua',
            'tab'   => $kunci,
        ], array_keys(HomeService::TAB_KABAR), HomeService::TAB_KABAR),
    ]) ?>
    <?php foreach (HomeService::TAB_KABAR as $kunci => [$labelTab]):
        $isiPanel = ($kabar[$kunci] ?? []) === []
            ? $this->insert('components/empty-state', ['judul' => 'Belum ada ' . mb_strtolower($labelTab), 'ikon' => 'newspaper'])
            : $this->insert('components/carousel', [
                'label'  => 'Kabar: ' . $labelTab,
                'slides' => array_map(fn (array $p): string => $this->insert('components/card-post', ['post' => $p]), $kabar[$kunci]),
            ]);
    ?>
    <?php if ($kunci === 'semua'): ?>
    <div class="mt-5" data-tab-panel="<?= e($kunci) ?>"><?= $isiPanel ?></div>
    <?php else: ?>
    <?php /* Tab lain di <template>: tidak masuk DOM aktif (lebih ringan) sampai dipilih — tabs.js menyisipkannya */ ?>
    <div class="mt-5" data-tab-panel="<?= e($kunci) ?>" hidden><template data-tab-isi><?= $isiPanel ?></template></div>
    <?php endif ?>
    <?php endforeach ?>
</section>

<?php /* 7. Video */ ?>
<?php if ($video !== []): ?>
<section class="cv-auto bg-surface" aria-labelledby="judul-video">
    <div class="<?= $blok ?>">
        <?= $this->insert('components/section-title', ['judul' => 'Video', 'id' => 'judul-video', 'subjudul' => 'Kisah penyaluran zakat dari lapangan.', 'link' => '/video']) ?>
        <?= $this->insert('components/carousel', [
            'label'   => 'Video terbaru',
            'kolomLg' => 3,
            'slides'  => array_map(fn (array $v): string => $this->insert('components/card-video', ['video' => $v]), $video),
        ]) ?>
    </div>
</section>
<?php endif ?>

<?php /* 8. Penjelasan Zakat */ ?>
<?php if ($zakat !== []): ?>
<section class="cv-auto <?= $blok ?>" aria-labelledby="judul-zakat">
    <?= $this->insert('components/section-title', ['judul' => 'Kenali Zakat', 'id' => 'judul-zakat', 'subjudul' => 'Pahami jenis zakat sebelum menunaikannya.', 'link' => '/zakat']) ?>
    <ul class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <?php foreach ($zakat as $z): ?>
        <li>
            <?php /* Foto dari admin → Penjelasan Zakat (mendatar ±2:1); tanpa foto = ikon buku */ ?>
            <a href="<?= e(url('zakat/' . $z['slug'])) ?>" class="group flex h-full flex-col rounded-xl border border-gray-200 bg-white p-1.5 text-sm font-semibold text-ink transition hover:border-primary hover:text-primary hover:shadow-md">
                <span class="block aspect-[2/1] overflow-hidden rounded-lg bg-primary/10">
                    <?php if (!empty($z['foto'])): ?>
                    <?= img($z['foto'], 'zakat', '', ['sizes' => '(min-width: 1024px) 220px, (min-width: 640px) 33vw, 50vw',
                        'class' => 'size-full object-cover transition-transform duration-300 group-hover:scale-105 motion-reduce:transition-none motion-reduce:group-hover:scale-100']) ?>
                    <?php else: ?>
                    <span class="grid size-full place-items-center text-primary"><?= icon('book', 'size-8') ?></span>
                    <?php endif ?>
                </span>
                <span class="flex flex-1 items-center px-1.5 pt-2 pb-1 leading-snug"><?= e($z['judul']) ?></span>
            </a>
        </li>
        <?php endforeach ?>
    </ul>
    <div class="mt-6 flex flex-col items-start gap-4 rounded-2xl bg-primary p-6 text-white sm:flex-row sm:items-center sm:justify-between lg:p-8">
        <div>
            <p class="text-lg font-bold lg:text-xl">Berapa zakat yang harus Anda tunaikan?</p>
            <p class="mt-1 text-white/85">Hitung zakat penghasilan, emas, perdagangan, dan fidyah dalam hitungan detik.</p>
        </div>
        <?= $this->insert('components/button', ['label' => 'Buka Kalkulator', 'href' => '/kalkulator-zakat', 'variant' => 'light', 'icon' => 'calculator', 'class' => 'shrink-0']) ?>
    </div>
</section>
<?php endif ?>

<?php /* 9. Testimoni + form kirim testimoni (muzaki/mustahik mengisi sendiri, dimoderasi admin) */ ?>
<?php $formTerbuka = App\Core\Session::getFlash('testimoni_terkirim') || App\Core\Session::getFlash('errors') ?>
<section class="cv-auto bg-surface" aria-labelledby="judul-testimoni">
    <div class="<?= $blok ?>">
        <?= $this->insert('components/section-title', ['judul' => 'Kata Mereka', 'id' => 'judul-testimoni', 'subjudul' => 'Pengalaman muzaki dan mustahik bersama BAZNAS Bangka Selatan.'] + ($testimoni !== [] ? ['link' => '/testimoni'] : [])) ?>
        <?php if ($testimoni !== []): ?>
        <?= $this->insert('components/carousel', [
            'label'     => 'Testimoni',
            'itemClass' => 'w-[85%] sm:w-[45%] lg:w-[calc((100%-2*1rem)/3)]',
            'slides'    => array_map(fn (array $t): string => $this->insert('components/card-testimoni', ['testimoni' => $t]), $testimoni),
        ]) ?>
        <?php endif ?>
        <details id="kirim-testimoni" class="group mt-8 scroll-mt-24 rounded-2xl border border-gray-200 bg-white shadow-sm"<?= $formTerbuka ? ' open' : '' ?>>
            <summary class="flex cursor-pointer list-none items-center gap-4 p-5 lg:p-6 [&::-webkit-details-marker]:hidden">
                <span class="grid size-12 shrink-0 place-items-center rounded-2xl bg-accent/20 text-primary"><?= icon('star', 'size-6') ?></span>
                <span class="min-w-0 flex-1">
                    <span class="block font-bold text-ink lg:text-lg">Bagikan pengalaman Anda</span>
                    <span class="block text-sm text-muted">Muzaki atau mustahik? Ceritakan pengalaman Anda bersama BAZNAS Bangka Selatan.</span>
                </span>
                <span class="hidden shrink-0 rounded-full bg-primary px-4 py-2 text-sm font-bold text-white group-open:hidden sm:inline-flex">Tulis testimoni</span>
                <?= icon('chevron-down', 'size-5 shrink-0 text-muted transition-transform group-open:rotate-180 sm:hidden') ?>
            </summary>
            <div class="border-t border-gray-200 p-5 lg:p-6">
                <?= $this->insert('components/form-testimoni', ['asal' => 'beranda']) ?>
            </div>
        </details>
    </div>
</section>

<?php /* 10. Mitra (latar putih — bagian testimoni di atasnya kini selalu tampil berlatar abu) */ ?>
<?php if ($mitra !== []): ?>
<section id="mitra" class="cv-auto scroll-mt-16" aria-labelledby="judul-mitra">
    <div class="<?= $blok ?>">
        <?= $this->insert('components/section-title', ['judul' => 'Mitra Kami', 'id' => 'judul-mitra', 'tengah' => true]) ?>
        <ul tabindex="0" aria-label="Logo mitra — geser untuk melihat lainnya"
            class="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2 scrollbar-none lg:mx-0 lg:flex-wrap lg:justify-center lg:overflow-visible lg:px-0">
            <?php foreach ($mitra as $m): ?>
            <li class="shrink-0 snap-start">
                <?php /* Logo berwarna asli; disorot → membesar (zoom in) di dalam kotaknya */ ?>
                <div class="group grid h-20 w-36 place-items-center overflow-hidden rounded-xl border border-gray-200 bg-white p-3 transition-shadow duration-300 hover:border-primary/30 hover:shadow-md">
                    <?= img($m['logo'], 'mitra', $m['nama'], [
                        'width' => $m['dim'][0] ?? null, 'height' => $m['dim'][1] ?? null, 'sizes' => '120px',
                        'class' => 'max-h-14 w-auto object-contain transition-transform duration-300 ease-out group-hover:scale-120 motion-reduce:transition-none motion-reduce:group-hover:scale-100',
                    ]) ?>
                </div>
            </li>
            <?php endforeach ?>
        </ul>
    </div>
</section>
<?php endif ?>

<?php $this->start('scripts') ?>
    <?php /* Prioritas rendah: tidak berebut bandwidth dengan gambar LCP; halaman sudah berfungsi tanpa JS */ ?>
    <script type="module" src="<?= e(asset('js/carousel.js')) ?>" fetchpriority="low"></script>
    <script type="module" src="<?= e(asset('js/tabs.js')) ?>" fetchpriority="low"></script>
    <script type="module" src="<?= e(asset('js/lite-yt.js')) ?>" fetchpriority="low"></script>
    <script type="module" src="<?= e(asset('js/testimoni.js')) ?>" fetchpriority="low"></script>
<?php $this->stop() ?>
